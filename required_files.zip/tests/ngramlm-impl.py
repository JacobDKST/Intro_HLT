OK_FORMAT = True

test = {   'name': 'ngramlm-impl',
    'points': 20,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_check_update():\n'
                                               '...     trigram_to_test = NgramLM(n=3)\n'
                                               '...     trigram_to_test.update(corpus[0])\n'
                                               '...     \n'
                                               '...     # contexts\n'
                                               '...     for ctx, words in random.choices(list(trigramlm.contexts.items()), k=10):\n'
                                               '...         ngram_words = set()\n'
                                               '...         for ng, count in trigramlm.ngrams.items():\n'
                                               '...             if ng[:-1] != ctx:\n'
                                               '...                 continue\n'
                                               '...             ngram_words.add(ng[-1])\n'
                                               "...         assert words == ngram_words, f'Seen words in `contexts` do not match with `ngrams`, {words} != {ngram_words}'\n"
                                               '...     \n'
                                               '...     # vocab\n'
                                               "...     ref_vocab = {'and', 'are', 'buonapartes', 'estates', 'family', 'genoa', 'just', 'lucca', 'now', 'of', 'prince', 'so', 'the', 'well', '~'}\n"
                                               "...     assert '~' in trigramlm.vocab, '~ is not in the Vocab.'\n"
                                               "...     assert len(trigram_to_test.vocab & ref_vocab) == 15, 'Vocab is not updated correctly.'\n"
                                               '...     \n'
                                               '...     # ngrams\n'
                                               "...     ref_counter = Counter({('~', '~', 'well'): 1,\n"
                                               "...          ('~', 'well', 'prince'): 1,\n"
                                               "...          ('well', 'prince', 'so'): 1,\n"
                                               "...          ('prince', 'so', 'genoa'): 1,\n"
                                               "...          ('so', 'genoa', 'and'): 1,\n"
                                               "...          ('genoa', 'and', 'lucca'): 1,\n"
                                               "...          ('and', 'lucca', 'are'): 1,\n"
                                               "...          ('lucca', 'are', 'now'): 1,\n"
                                               "...          ('are', 'now', 'just'): 1,\n"
                                               "...          ('now', 'just', 'family'): 1,\n"
                                               "...          ('just', 'family', 'estates'): 1,\n"
                                               "...          ('family', 'estates', 'of'): 1,\n"
                                               "...          ('estates', 'of', 'the'): 1,\n"
                                               "...          ('of', 'the', 'buonapartes'): 1,\n"
                                               "...          ('the', 'buonapartes', '~'): 1,\n"
                                               "...          ('buonapartes', '~', '~'): 1})\n"
                                               "...     assert set(trigram_to_test.ngrams.keys()) == set(ref_counter.keys()), 'Wrong ngram counting.'\n"
                                               '...     for k in ref_counter.keys():\n'
                                               "...         assert trigram_to_test.ngrams[k] == ref_counter[k], f'{trigram_to_test.ngrams[k]} != {ref_counter[k]}'\n"
                                               '...         \n'
                                               '...     # ngram_contexts\n'
                                               "...     context_ref_counter = Counter({('~', '~'): 1,\n"
                                               "...          ('~', 'well'): 1,\n"
                                               "...          ('well', 'prince'): 1,\n"
                                               "...          ('prince', 'so'): 1,\n"
                                               "...          ('so', 'genoa'): 1,\n"
                                               "...          ('genoa', 'and'): 1,\n"
                                               "...          ('and', 'lucca'): 1,\n"
                                               "...          ('lucca', 'are'): 1,\n"
                                               "...          ('are', 'now'): 1,\n"
                                               "...          ('now', 'just'): 1,\n"
                                               "...          ('just', 'family'): 1,\n"
                                               "...          ('family', 'estates'): 1,\n"
                                               "...          ('estates', 'of'): 1,\n"
                                               "...          ('of', 'the'): 1,\n"
                                               "...          ('the', 'buonapartes'): 1,\n"
                                               "...          ('buonapartes', '~'): 1})\n"
                                               "...     assert set(trigram_to_test.ngram_contexts.keys()) == set(context_ref_counter.keys()), 'Wrong ngram context updates.'\n"
                                               '...     for k in context_ref_counter.keys():\n'
                                               "...         assert trigram_to_test.ngram_contexts[k] == context_ref_counter[k], f'{trigram_to_test.ngram_contexts[k]} != {context_ref_counter[k]}'\n"
                                               '>>> \n'
                                               '>>> pub_test_check_update()\n',
                                       'failure_message': 'Failed testing `.update()` method.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 4},
                                   {   'code': '>>> def pub_test_next_word_candidates():\n'
                                               "...     inclusion_check = {'infantry', 'charming', 'tomorrow', 'flower', 'shouts', 'twice', 'mutiny', 'zhilinski', 'their', 'mishka'}\n"
                                               '...     for i in inclusion_check:\n'
                                               "...         assert i in trigramlm.next_word_candidates(('~', '~')), f'{i} is not included under (~, ~)'\n"
                                               '...     \n'
                                               "...     inclusion_check_2 = {'another', 'her', 'nesvitski', 'princess', 'something', 'the', 'zherkov', '~'}\n"
                                               '...     for i in inclusion_check_2:\n'
                                               "...         assert i in trigramlm.next_word_candidates(('them', 'said')), f'{i} is not included under (them, said)'\n"
                                               '>>> \n'
                                               '>>> pub_test_next_word_candidates()\n',
                                       'failure_message': 'Failed testing `.next_word_candidates()`.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2},
                                   {   'code': '>>> def pub_test_word_prob():\n'
                                               "...     assert np.isclose(trigramlm.word_prob(('~', '~'), 'hi'), 6.24e-05, atol=1e-7)\n"
                                               "...     assert np.isclose(trigramlm.word_prob(('~', '~'), 'another'), 0.0014357, atol=1e-7)\n"
                                               "...     assert np.isclose(trigramlm.word_prob(('the', 'gentle'), 'princess') , 0.25, atol=1e-7)\n"
                                               "...     assert np.isclose(trigramlm.word_prob(('to', 'a'), 'battle'), 0.00873362, atol=1e-7)\n"
                                               "...     assert np.isclose(trigramlm.word_prob(('to', 'a'), 'trot'), 0.0131004, atol=1e-7)\n"
                                               '...     \n'
                                               '>>> pub_test_word_prob()\n',
                                       'failure_message': 'Failed testing `.word_prob()`.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2},
                                   {   'code': '>>> def pub_test_random_word():\n'
                                               "...     candidates = {'bad', 'ball', 'battle', 'battlefield', 'bear', 'big', 'blue', 'bookshop', 'borzoi', 'breadth', 'broad', 'brother', 'building', "
                                               "'bullet', 'campaign', 'campfire', 'cannon', 'captaincy', 'cart', 'cause', 'certain', 'chair', 'chit', 'churlish', 'close', 'column', 'common', "
                                               "'commotion', 'companion', 'company', 'comrade', 'conclusion', 'cone', 'conflict', 'conjunction', 'consultation', 'convoy', 'copse', 'corner', "
                                               "'cornetcy', 'corresponding', 'cossack', 'countess', 'country', 'crowd', 'custom', 'daughter', 'demand', 'different', 'diplomatic', 'disgrace', "
                                               "'dispatch', 'distant', 'dresser', 'duel', 'feeling', 'fellow', 'fete', 'field', 'fight', 'folk', 'footman', 'former', 'french', 'frenchman', 'friend', "
                                               "'frightened', 'functionary', 'gallop', 'general', 'gentleman', 'great', 'group', 'halt', 'head', 'heavy', 'herd', 'high', 'higher', 'hole', 'horse', "
                                               "'hotel', 'house', 'husband', 'knoll', 'lackey', 'lady', 'large', 'lesser', 'little', 'long', 'man', 'map', 'merchant', 'mirror', 'mosque', 'mounted', "
                                               "'new', 'newly', 'noble', 'pale', 'partner', 'party', 'path', 'patriotic', 'peasant', 'pistil', 'place', 'polish', 'portly', 'power', 'prince', "
                                               "'printed', 'prominent', 'promised', 'proposal', 'reception', 'remark', 'remote', 'republican', 'reunion', 'review', 'roman', 'round', 'running', "
                                               "'russian', 'savage', 'secondary', 'series', 'simple', 'single', 'small', 'smart', 'society', 'soldier', 'spot', 'staff', 'standstill', 'stop', "
                                               "'stout', 'stranger', 'sublieutenancy', 'suffering', 'suggestion', 'superficial', 'sutler', 'tall', 'thin', 'third', 'thousand', 'trot', 'tune', "
                                               "'turreted', 'very', 'vision', 'vivid', 'walk', 'want', 'well', 'whole', 'wizard', 'woman', 'wounded'}\n"
                                               "...     gen_seq = [trigramlm.random_word(('to', 'a')) for _ in range(10)]\n"
                                               '...     for w in gen_seq:\n'
                                               "...         assert w in candidates, f'{w} should be one of the candidates'\n"
                                               '>>> \n'
                                               '>>> pub_test_random_word()\n',
                                       'failure_message': 'Failed testing `.random_word()`.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2},
                                   {   'code': '>>> def pub_test_random_text(): \n'
                                               '...     gen_seq = [trigramlm.random_text(i) for i in range(2, 10)]\n'
                                               '...     for seq in gen_seq:\n'
                                               '...         for grams in zip(*[seq[i:] for i in range(trigramlm.n)]):\n'
                                               "...             assert grams[-1] in trigramlm.contexts[tuple(grams[:-1])], f'Unseen word {grams[-1]} was generated.'\n"
                                               '>>> \n'
                                               '>>> pub_test_random_text()\n',
                                       'failure_message': 'Failed testing `.random_text()`.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
