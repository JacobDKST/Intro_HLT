OK_FORMAT = True

test = {   'name': 'ngramlm-tri-perp-on-dev',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def hid_test_trigram_perp_on_dev():\n...     assert np.isclose(trigram_perp_on_dev, np.inf)\n>>> \n>>> hid_test_trigram_perp_on_dev()\n',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
